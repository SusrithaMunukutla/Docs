#!/bin/bash
sudo yum update -y
sudo yum install -y docker
sudo service docker start
echo "
[gocd]
name     = GoCD YUM Repository
baseurl  = https://download.go.cd
enabled  = 1
gpgcheck = 1
gpgkey   = https://download.go.cd/GOCD-GPG-KEY.asc
" | sudo tee /etc/yum.repos.d/gocd.repo
sudo yum install -y java-1.7.0-openjdk
sudo yum install -y git
sudo yum install -y go-agent
sudo /etc/init.d/go-agent start
cd /opt
sudo wget --no-cookies --no-check-certificate --header "Cookie: gpw_e24=http%3A%2F%2Fwww.oracle.com%2F; oraclelicense=accept-securebackup-cookie" "http://download.oracle.com/otn-pub/java/jdk/8u111-b14/jdk-8u111-linux-x64.tar.gz"
sudo tar xzf jdk-8u111-linux-x64.tar.gz
sudo wget http://www-eu.apache.org/dist/maven/maven-3/3.3.9/binaries/apache-maven-3.3.9-bin.tar.gz
sudo tar xvf apache-maven-3.3.9-bin.tar.gz
sudo su go
echo "export JAVA_HOME=/opt/jdk1.8.0_111 " >> /etc/profile
source /etc/profile
echo "export PATH=/opt/jdk1.8.0_111/bin:$PATH " >> /etc/profile
source /etc/profile
echo "export M2_HOME=/opt/apache-maven-3.3.9 " >> /etc/profile
source /etc/profile
echo "export PATH=$PATH:/opt/apache-maven-3.3.9/bin " >> /etc/profile
source /etc/profile
sed -i -e 's/127.0.0.1/172.31.0.10/g' /etc/default/go-agent
sudo su
usermod -a -G docker ec2-user
usermod -a -G docker go
usermod -a -G wheel go
/etc/init.d/go-agent restart
#********************Installing Zookeeper and kafka*************************************************
cd /opt
wget http://redrockdigimark.com/apachemirror/zookeeper/zookeeper-3.4.6/zookeeper-3.4.6.tar.gz
tar xvzf zookeeper-3.4.6.tar.gz
cd /opt/zookeeper-3.4.6
mkdir data
cd ..
touch /opt/zookeeper-3.4.6/conf/zoo.cfg
echo " tickTime=2000
dataDir=/opt/zookeeper-3.4.6/data
clientPort=2181
initLimit=5
syncLimit=2 " >> /opt/zookeeper-3.4.6/conf/zoo.cfg
cd /opt/zookeeper-3.4.6
bin/zkServer.sh start &
source /etc/profile
cd /opt/
wget http://www.trieuvan.com/apache/kafka/0.10.0.0/kafka_2.10-0.10.0.0.tgz
tar xvzf kafka_2.10-0.10.0.0.tgz
cd  kafka_2.10-0.10.0.0
bin/kafka-server-start.sh config/server.properties &
source /etc/profile