#!/bin/bash
echo "
[gocd]
name     = GoCD YUM Repository
baseurl  = https://download.go.cd
enabled  = 1
gpgcheck = 1
gpgkey   = https://download.go.cd/GOCD-GPG-KEY.asc
" | sudo tee /etc/yum.repos.d/gocd.repo
sudo yum install -y java-1.7.0-openjdk
sudo yum install -y go-server
sudo yum install -y git
sudo su
echo "export GO_SERVER_SYSTEM_PROPERTIES='-Dgo.plugin.upload.enabled=true'" >> /etc/default/go-server
git clone https://github.com/samhitha30/kubernetes_configfiles.git
cp /kubernetes_configfiles/gocd-docker-pipeline-plugin-1.0.0.jar /var/lib/go-server/plugins/external/
sudo /etc/init.d/go-server restart