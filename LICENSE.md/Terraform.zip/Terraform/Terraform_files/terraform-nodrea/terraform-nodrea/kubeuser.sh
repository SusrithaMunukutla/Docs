#cd /home/ec2-user/kubeterra
cd /root
#echo "eport HOME=/root" >> /etc/profile
#source /etc/profile
#echo "displaying path" $HOME
wget https://github.com/kubernetes/kubernetes/releases/download/v1.4.6/kubernetes.tar.gz
tar -xvzf kubernetes.tar.gz
#export KUBERNETES_PROVIDER=aws
#export PATH=/kubernetes/platforms/linux/amd64:$PATH
sed -i -e 's/us-west-2a/ap-northeast-1a/g' /root/kubernetes/cluster/aws/config-default.sh
sed -i -e 's/NUM_NODES:-4/NUM_NODES:-2/g' /root/kubernetes/cluster/aws/config-default.sh
sed -i -e 's/NODE_SIZE="t2.micro"/NODE_SIZE="t2.medium"/g' /root/kubernetes/cluster/aws/config-default.sh
#sed -i -e 's/MASTER_SIZE="m3.medium"/MASTER_SIZE="t2.micro"/g' /root/kubernetes/cluster/aws/config-default.sh
sed -i -e 's/us-east-1/ap-northeast-1/g' /root/kubernetes/cluster/aws/config-default.sh
sed -i -e 's/KUBE_OS_DISTRIBUTION:-jessie/KUBE_OS_DISTRIBUTION:-wily/g' /root/kubernetes/cluster/aws/config-default.sh

#auto-scaling, cidr, existing key, yaml files --to be added
cd ~
mkdir .aws
echo "[default]
aws_access_key_id=AKIAII4HQL7323BTPCLA
aws_secret_access_key=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
region=ap-northeast-1
output=json" >  ~/.aws/config

echo "export HOME=/root" >> /etc/profile
source /etc/profile
echo "displaying path" $HOME

source /etc/profile
echo "export KUBERNETES_PROVIDER=aws" >> /etc/profile
source /etc/profile
echo "export PATH=/root/kubernetes/platforms/linux/amd64:$PATH" >> /etc/profile
source /etc/profile
#export KUBERNETES_PROVIDER=aws
#export PATH=/kubernetes/platforms/linux/amd64:$PATH
cd /root/kubernetes/cluster/
source /etc/profile
#cd /home/ec2-user/kubeterra/kubernetes/cluster/
./kube-up.sh >> kubeuplog.txt
cd ~
#******MERCHANT_BROKER JSON*****
mkdir merchantapplication
git clone https://github.com/samhitha30/mydocker.git /root/merchantjsonfiles
cp /root/merchantjsonfiles/Merchant/merchantapp-controller.json /root/merchantapplication
cp /root/merchantjsonfiles/Merchant/merchantapp-service.json /root/merchantapplication
cd /root/merchantapplication
kubectl create -f /root/merchantapplication/
#******PAYMENT_API JSON*******\
cd ~
mkdir paymentapplication
git clone https://github.com/samhitha30/mydocker.git /root/paymentjsonfiles
cp /root/paymentjsonfiles/payment_api/payment-controller.json /root/paymentapplication
cp /root/paymentjsonfiles/payment_api/payment-service.json /root/paymentapplication
cd /root/paymentapplication
kubectl create -f /root/paymentapplication/
#**********PSP_PROVIDERS JSON********
cd ~
mkdir pspapplication
git clone https://github.com/samhitha30/mydocker.git /root/paymentjsonfiles
cp /root/paymentjsonfiles/payment_api/payment-controller.json /root/paymentapplication
cp /root/paymentjsonfiles/payment_api/payment-service.json /root/paymentapplication
cd /root/paymentapplication
kubectl create -f /root/paymentapplication/
#**********PSP_PROVIDERS JSON********
cd ~
mkdir pspapplication
git clone https://github.com/samhitha30/mydocker.git /root/pspjsonfiles
cp /root/pspjsonfiles/psp_providers/psp-controller.json /root/pspapplication
cp /root/pspjsonfiles/psp_providers/psp-service.json /root/pspapplication
cd /root/pspapplication
kubectl create -f /root/pspapplication/
#kubectl autoscale rc merchantapp --max=7 --cpu-percent=7
cd ~
kubectl config view >> kubecredentials.txt
git clone https://github.com/samhitha30/mydocker.git /root/gitrepocred
echo 'y' | cp /root/kubecredentials.txt /root/gitrepocred/
cd /root/gitrepocred/
git init
git remote set-url origin https://samhitha30:welcome123@github.com/samhitha30/mydocker.git
git config --global user.email "samhitha225@gmail.com"
git config --global user.name "samhitha30"
git add .
git commit -m 'added credentials file'
git push
sudo /etc/init.d/go-agent restart